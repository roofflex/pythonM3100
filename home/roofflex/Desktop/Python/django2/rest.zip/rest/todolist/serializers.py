from rest_framework import serializers
from .models import Task,Tasklist,Tag


class UserSerializer(serializers.ModelSerializer):
    vipusers = serializers.PrimaryKeyRelatedField(many=True, queryset=Task.objects.all())
    view_users = serializers.PrimaryKeyRelatedField(many=True, queryset=Task.objects.all())
    class Meta:
        model = 'auth.User'
        fields = ('id', 'username', 'vipusers', 'view_users', )

class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ('id', 'name','task_set')
        read_only_fields = ('task_set',)

class TaskSerializer(serializers.ModelSerializer):
    tags = serializers.SlugRelatedField(many=True, slug_field='name', queryset=Tag.objects.all())

    class Meta:
        model = Task
        fields = ('id', 'name', 'description', 'completed', 'date_created', 'date_modified', 'due_date', 'priority','tags')
        read_only_fields = ('date_created', 'date_modified',)



class TasklistSerializer(serializers.ModelSerializer):
    tasks = serializers.StringRelatedField(many=True)

    class Meta:
        model = Tasklist
        fields = ('name', 'tasks', 'id','vipusers', 'view_users' )
        read_only_fields = ('owner',)


